YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "NanoScroll"
    ],
    "modules": [],
    "allModules": []
} };
});